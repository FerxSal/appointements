package com.agrilands.agrilands;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgriLandsApplicationTests {

	@Test
	void contextLoads() {
	}

}
