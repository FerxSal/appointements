package com.appointments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgriLandsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgriLandsApplication.class, args);
	}

}
