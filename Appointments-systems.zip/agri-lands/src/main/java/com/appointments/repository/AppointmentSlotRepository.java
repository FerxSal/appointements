package com.appointments.repository;



import model.AppointmentSlot;
import model.TimeSlot;
import org.springframework.data.repository.CrudRepository;


import java.util.List;

public interface AppointmentSlotRepository extends CrudRepository<AppointmentSlot, Long> {



    List<AppointmentSlot> findAllByTimeSlot(TimeSlot timeSlot);


    List<AppointmentSlot>  findAllByTimeSlotAndType(TimeSlot timeSlot,String startType,String endType);
}
