package com.appointments.repository;


import model.AppointmentReservation;
import org.springframework.data.repository.CrudRepository;

public interface AppointmentReservationsRepository extends CrudRepository<AppointmentReservation, Long> {



}
