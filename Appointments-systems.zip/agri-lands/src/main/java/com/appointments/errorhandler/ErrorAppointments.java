package com.appointments.errorhandler;

public class ErrorAppointments extends Exception {


    public ErrorAppointments(String errorMessge) {
     super(errorMessge);

    }



}
