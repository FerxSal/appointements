package com.appointments.Service;


import com.appointments.errorhandler.ErrorAppointments;
import com.appointments.repository.AppointmentReservationsRepository;
import com.appointments.repository.AppointmentSlotRepository;
import model.AppointmentReservation;
import model.AppointmentSlot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AppointmentsService {


    @Autowired
    AppointmentSlotRepository appointmentSlotRepository;

    @Autowired
    AppointmentReservationsRepository appointmentReservationsRepository;


    public AppointmentReservation createNewAppointSlot(AppointmentSlot appointmentSlot, AppointmentReservation appointmentReservation) throws ErrorAppointments {


        if (appointmentSlotRepository.findAllByTimeSlot(appointmentSlot.getTimeSlot()).isEmpty()) {

            appointmentSlotRepository.save(appointmentSlot);
            appointmentReservationsRepository.save(appointmentReservation);
        } else {

            throw new ErrorAppointments("Error creating Appointment");
        }

        return appointmentReservation;

    }


    public AppointmentReservation updateAppointment(AppointmentReservation appointmentReservation) throws ErrorAppointments {

        if (appointmentReservationsRepository.existsById(appointmentReservation.getId())) {

            appointmentReservationsRepository.save(setAppointmentData(appointmentReservation));

        } else {

            throw new ErrorAppointments("Appointment does not exists");
        }

        return appointmentReservation;

    }

    private AppointmentReservation setAppointmentData(AppointmentReservation appointmentReservation){

          AppointmentReservation appointmentReservationNew = new AppointmentReservation();

          appointmentReservationNew.setCustomername(appointmentReservation.getcustomerName());
          appointmentReservationNew.setEmail(appointmentReservation.getEmail());
          appointmentReservationNew.setPhone(appointmentReservation.getPhone());

          return appointmentReservationNew;
    }
}