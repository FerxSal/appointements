package com.appointments.com.appointments.controller;

import com.appointments.Service.AppointmentsService;
import com.appointments.errorhandler.ErrorAppointments;
import com.appointments.repository.AppointmentReservationsRepository;
import com.appointments.repository.AppointmentSlotRepository;
import model.AppointmentReservation;
import model.AppointmentSlot;
import model.TimeSlot;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.text.SimpleDateFormat;
import java.util.*;


@RestController
@RequestMapping("/appointments")
public class AppointmentSlotsController {


    private static final Logger LOGGER = LoggerFactory.getLogger(AppointmentSlotsController.class);

    @Autowired
    AppointmentsService appointmentsService;

    @Autowired
    private AppointmentReservationsRepository reservationsRepository;

    @Autowired
    private AppointmentSlotRepository appointmentSlotRepository;


    @GetMapping("/{startDate}/{endDate}")
    public ResponseEntity<List<AppointmentSlot>> availableSlots(String startDate, String endDate) {

        TimeSlot timeSlot = new TimeSlot(LocalDateTime.parse(startDate), LocalDateTime.parse(endDate));

        List<AppointmentSlot> appointmentSlots = appointmentSlotRepository.findAllByTimeSlot(timeSlot);

        return ResponseEntity.ok(appointmentSlots);
    }


    /**
     * Query available appt. slots within a date range of certain type (AM, PM, etc.)
     * @Params startDate, endDate, startType (AM/PM/EV),  endType (AM/PM/EV)
     */
    @GetMapping("/{startDate}/{endDate}/{startType}/{endType}")
    public ResponseEntity<List<AppointmentSlot>> availableSlotsWithType(String startDate, String endDate, String startType, String endType ){

        TimeSlot timeSlot = new TimeSlot(LocalDateTime.parse(startDate) , LocalDateTime.parse(endDate));
        SimpleDateFormat formatTime = new SimpleDateFormat("hh.mm aa");

        startType =  formatTime.format(startDate);
        endType = formatTime.format(endDate);

        List<AppointmentSlot>  res = appointmentSlotRepository.findAllByTimeSlotAndType(timeSlot,startType,endType);

        return ResponseEntity.ok(res);

    }

    /**
     * Create an appointment reservation for a slot providing the customer details
     */
    @PostMapping("/submitAppointment")
    public ResponseEntity<AppointmentReservation> createNewAppointment(AppointmentSlot appointmentSlot, AppointmentReservation appointmentReservation) throws ErrorAppointments {

        return ResponseEntity.ok(appointmentsService.createNewAppointSlot(appointmentSlot,appointmentReservation));

    }

    /**
     * Query the details for a reserved appointment
     *  @Params id
     * @return AppointmentReservation
     */
    @GetMapping("/{id}")
    public ResponseEntity<Optional<AppointmentReservation>> getDetailsAppointmentReservation(Long id){

      Optional<AppointmentReservation> reservation = reservationsRepository.findById(id);

      if (reservation.isPresent()) {
          return ResponseEntity.ok(reservation);
      }
      else {

          return new ResponseEntity(HttpStatus.NOT_FOUND);
      }

    }

    /**
     *  Update the contact details for a reserved appointment
     */
    @PutMapping("/updateAppointment")
    public ResponseEntity<AppointmentReservation> updateAppointmentReservation(AppointmentReservation appointmentReservation) throws ErrorAppointments {

        return ResponseEntity.ok(appointmentsService.updateAppointment(appointmentReservation));
    }


    /**
     *  Cancel a reserved appointment
     */
    @DeleteMapping("/cancelAppointment/{id}") void cancelAppointment(Long id){

            reservationsRepository.deleteById(id);
    }

}
