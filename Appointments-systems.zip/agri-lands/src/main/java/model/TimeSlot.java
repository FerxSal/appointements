package model;


import org.joda.time.LocalDateTime;


public class TimeSlot {

    LocalDateTime starTime;

    LocalDateTime endTime;


    public TimeSlot(LocalDateTime starTime, LocalDateTime endTime) {
        this.starTime = starTime;
        this.endTime = endTime;
    }

    public LocalDateTime getStarTime() {
        return starTime;
    }

    public void setStarTime(LocalDateTime starTime) {
        this.starTime = starTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }
}
