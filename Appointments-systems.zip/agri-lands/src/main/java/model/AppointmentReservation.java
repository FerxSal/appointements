package model;

import org.springframework.data.annotation.Id;

import javax.persistence.*;
import java.io.Serializable;


@Entity
public class AppointmentReservation implements Serializable {


    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long id;
    private String customerName;
    private String email;
    private String phone;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getcustomerName() {
        return customerName;
    }

    public void setCustomername(String customerName) {
        this.customerName = customerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @ManyToOne
    @JoinColumn(name="appointmentslot_id")
    private AppointmentSlot appointmentSlot;


}
