package model;

import org.springframework.data.annotation.Id;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.io.Serializable;


@Entity
public class AppointmentSlot implements Serializable {


    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private long appointmentslot_id;
    private TimeSlot timeSlot;

    public long getAppointmentslot_id() {
        return appointmentslot_id;
    }

    public void setAppointmentslot_id(long appointmentslot_id) {
        this.appointmentslot_id = appointmentslot_id;
    }

    public TimeSlot getTimeSlot() {
        return timeSlot;
    }

    public void setTimeSlot(TimeSlot timeSlot) {
        this.timeSlot = timeSlot;
    }
}
